gdjs.BossCode = {};
gdjs.BossCode.GDScoreObjects1= [];
gdjs.BossCode.GDScoreObjects2= [];
gdjs.BossCode.GDHealthObjects1= [];
gdjs.BossCode.GDHealthObjects2= [];
gdjs.BossCode.GDEnemyHealthObjects1= [];
gdjs.BossCode.GDEnemyHealthObjects2= [];
gdjs.BossCode.GDCongratsObjects1= [];
gdjs.BossCode.GDCongratsObjects2= [];
gdjs.BossCode.GDDieObjects1= [];
gdjs.BossCode.GDDieObjects2= [];
gdjs.BossCode.GDPlayerObjects1= [];
gdjs.BossCode.GDPlayerObjects2= [];
gdjs.BossCode.GDBulletObjects1= [];
gdjs.BossCode.GDBulletObjects2= [];
gdjs.BossCode.GDBossMonsterObjects1= [];
gdjs.BossCode.GDBossMonsterObjects2= [];
gdjs.BossCode.GDSnowballObjects1= [];
gdjs.BossCode.GDSnowballObjects2= [];
gdjs.BossCode.GDFallingSnowObjects1= [];
gdjs.BossCode.GDFallingSnowObjects2= [];
gdjs.BossCode.GDStumpObjects1= [];
gdjs.BossCode.GDStumpObjects2= [];
gdjs.BossCode.GDRunwayObjects1= [];
gdjs.BossCode.GDRunwayObjects2= [];
gdjs.BossCode.GDKeyObjects1= [];
gdjs.BossCode.GDKeyObjects2= [];
gdjs.BossCode.GDgateObjects1= [];
gdjs.BossCode.GDgateObjects2= [];
gdjs.BossCode.GDPlaneObjects1= [];
gdjs.BossCode.GDPlaneObjects2= [];
gdjs.BossCode.GDdarkObjects1= [];
gdjs.BossCode.GDdarkObjects2= [];
gdjs.BossCode.GDBarriorObjects1= [];
gdjs.BossCode.GDBarriorObjects2= [];
gdjs.BossCode.GDSignObjects1= [];
gdjs.BossCode.GDSignObjects2= [];

gdjs.BossCode.conditionTrue_0 = {val:false};
gdjs.BossCode.condition0IsTrue_0 = {val:false};
gdjs.BossCode.condition1IsTrue_0 = {val:false};
gdjs.BossCode.condition2IsTrue_0 = {val:false};
gdjs.BossCode.conditionTrue_1 = {val:false};
gdjs.BossCode.condition0IsTrue_1 = {val:false};
gdjs.BossCode.condition1IsTrue_1 = {val:false};
gdjs.BossCode.condition2IsTrue_1 = {val:false};


gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.BossCode.GDBulletObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.BossCode.GDBulletObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBossMonsterObjects1Objects = Hashtable.newFrom({"BossMonster": gdjs.BossCode.GDBossMonsterObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDSnowballObjects1Objects = Hashtable.newFrom({"Snowball": gdjs.BossCode.GDSnowballObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.BossCode.GDPlayerObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDSnowballObjects1Objects = Hashtable.newFrom({"Snowball": gdjs.BossCode.GDSnowballObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDFallingSnowObjects1Objects = Hashtable.newFrom({"FallingSnow": gdjs.BossCode.GDFallingSnowObjects1});gdjs.BossCode.eventsList0 = function(runtimeScene) {

{


gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if (gdjs.BossCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.BossCode.eventsList1 = function(runtimeScene) {

{


gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if (gdjs.BossCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.BossCode.GDBulletObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBarriorObjects1Objects = Hashtable.newFrom({"Barrior": gdjs.BossCode.GDBarriorObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.BossCode.GDBulletObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDStumpObjects1Objects = Hashtable.newFrom({"Stump": gdjs.BossCode.GDStumpObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDSnowballObjects1Objects = Hashtable.newFrom({"Snowball": gdjs.BossCode.GDSnowballObjects1});gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDStumpObjects1Objects = Hashtable.newFrom({"Stump": gdjs.BossCode.GDStumpObjects1});gdjs.BossCode.eventsList2 = function(runtimeScene) {

{



}


{


gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.BossCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Congrats"), gdjs.BossCode.GDCongratsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Die"), gdjs.BossCode.GDDieObjects1);
{for(var i = 0, len = gdjs.BossCode.GDCongratsObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDCongratsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.BossCode.GDDieObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDDieObjects1[i].hide();
}
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "Gun-Shot.wav");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "walking-dead.mp3");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "walking-dead.mp3", true, 50, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("BossMonster"), gdjs.BossCode.GDBossMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BossCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BossCode.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.BossCode.GDPlayerObjects1.length !== 0 ? gdjs.BossCode.GDPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.BossCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDPlayerObjects1[i].setScale(0.7);
}
}{for(var i = 0, len = gdjs.BossCode.GDBossMonsterObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBossMonsterObjects1[i].setScale(2);
}
}{for(var i = 0, len = gdjs.BossCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBulletObjects1[i].setScale(0.7);
}
}{for(var i = 0, len = gdjs.BossCode.GDBossMonsterObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBossMonsterObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.BossCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.BossCode.GDPlayerObjects1[0].getPointX("")), (( gdjs.BossCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.BossCode.GDPlayerObjects1[0].getPointY("")));
}
}}

}


{



}


{


gdjs.BossCode.condition0IsTrue_0.val = false;
gdjs.BossCode.condition1IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.BossCode.condition0IsTrue_0.val ) {
{
{gdjs.BossCode.conditionTrue_1 = gdjs.BossCode.condition1IsTrue_0;
gdjs.BossCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8881140);
}
}}
if (gdjs.BossCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BossCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BossCode.GDPlayerObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "Gun-Shot.wav", false, 60, 1);
}{for(var i = 0, len = gdjs.BossCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDPlayerObjects1[i].getBehavior("FireBullet").Fire((gdjs.BossCode.GDPlayerObjects1[i].getPointX("")), (gdjs.BossCode.GDPlayerObjects1[i].getPointY("")), gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects, (gdjs.BossCode.GDPlayerObjects1[i].getBehavior("FaceForward").MovementDirection((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 600, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.BossCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.BossCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.BossCode.GDHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BossCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.BossCode.GDHealthObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDHealthObjects1[i].setString("Health: " + gdjs.evtTools.common.toString((( gdjs.BossCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.BossCode.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("BossMonster"), gdjs.BossCode.GDBossMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("EnemyHealth"), gdjs.BossCode.GDEnemyHealthObjects1);
{for(var i = 0, len = gdjs.BossCode.GDEnemyHealthObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDEnemyHealthObjects1[i].setString("BossHealth: " + gdjs.evtTools.common.toString((( gdjs.BossCode.GDBossMonsterObjects1.length === 0 ) ? 0 :gdjs.BossCode.GDBossMonsterObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossMonster"), gdjs.BossCode.GDBossMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BossCode.GDBulletObjects1);

gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects, gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBossMonsterObjects1Objects, false, runtimeScene, false);
}if (gdjs.BossCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BossCode.GDBossMonsterObjects1 */
/* Reuse gdjs.BossCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.BossCode.GDBossMonsterObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBossMonsterObjects1[i].getBehavior("Health").Hit(20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BossCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BossCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Snowball"), gdjs.BossCode.GDSnowballObjects1);

gdjs.BossCode.condition0IsTrue_0.val = false;
gdjs.BossCode.condition1IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDSnowballObjects1Objects, gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.BossCode.condition0IsTrue_0.val ) {
{
{gdjs.BossCode.conditionTrue_1 = gdjs.BossCode.condition1IsTrue_0;
gdjs.BossCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8888100);
}
}}
if (gdjs.BossCode.condition1IsTrue_0.val) {
/* Reuse gdjs.BossCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.BossCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDPlayerObjects1[i].getBehavior("Health").Hit(20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{}}

}


{


{
}

}


{


gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "Enemyfire");
}if (gdjs.BossCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BossMonster"), gdjs.BossCode.GDBossMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Snowball"), gdjs.BossCode.GDSnowballObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "Snow Shovel.wav", false, 40, 1);
}{for(var i = 0, len = gdjs.BossCode.GDBossMonsterObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBossMonsterObjects1[i].getBehavior("FireBullet").Fire((gdjs.BossCode.GDBossMonsterObjects1[i].getPointX("")), (gdjs.BossCode.GDBossMonsterObjects1[i].getPointY("")), gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDSnowballObjects1Objects, (gdjs.BossCode.GDBossMonsterObjects1[i].getBehavior("FaceForward").MovementDirection((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 300, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemyfire");
}}

}


{


gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "FallingSnow");
}if (gdjs.BossCode.condition0IsTrue_0.val) {
gdjs.BossCode.GDFallingSnowObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDFallingSnowObjects1Objects, gdjs.randomInRange(-(10), 1400), -(50), "Background");
}{for(var i = 0, len = gdjs.BossCode.GDFallingSnowObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDFallingSnowObjects1[i].addPolarForce(90, 300, 1);
}
}{for(var i = 0, len = gdjs.BossCode.GDFallingSnowObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDFallingSnowObjects1[i].rotate(10, runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FallingSnow");
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BossCode.GDPlayerObjects1);

gdjs.BossCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BossCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.BossCode.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BossCode.condition0IsTrue_0.val = true;
        gdjs.BossCode.GDPlayerObjects1[k] = gdjs.BossCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.BossCode.GDPlayerObjects1.length = k;}if (gdjs.BossCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Die"), gdjs.BossCode.GDDieObjects1);
{for(var i = 0, len = gdjs.BossCode.GDDieObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDDieObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.BossCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BossMonster"), gdjs.BossCode.GDBossMonsterObjects1);

gdjs.BossCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BossCode.GDBossMonsterObjects1.length;i<l;++i) {
    if ( gdjs.BossCode.GDBossMonsterObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BossCode.condition0IsTrue_0.val = true;
        gdjs.BossCode.GDBossMonsterObjects1[k] = gdjs.BossCode.GDBossMonsterObjects1[i];
        ++k;
    }
}
gdjs.BossCode.GDBossMonsterObjects1.length = k;}if (gdjs.BossCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BossCode.GDBossMonsterObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Congrats"), gdjs.BossCode.GDCongratsObjects1);
{for(var i = 0, len = gdjs.BossCode.GDBossMonsterObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBossMonsterObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.BossCode.GDCongratsObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDCongratsObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.BossCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barrior"), gdjs.BossCode.GDBarriorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BossCode.GDBulletObjects1);

gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects, gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBarriorObjects1Objects, false, runtimeScene, false);
}if (gdjs.BossCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BossCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.BossCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BossCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Stump"), gdjs.BossCode.GDStumpObjects1);

gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDBulletObjects1Objects, gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDStumpObjects1Objects, false, runtimeScene, false);
}if (gdjs.BossCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BossCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.BossCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Snowball"), gdjs.BossCode.GDSnowballObjects1);
gdjs.copyArray(runtimeScene.getObjects("Stump"), gdjs.BossCode.GDStumpObjects1);

gdjs.BossCode.condition0IsTrue_0.val = false;
{
gdjs.BossCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDSnowballObjects1Objects, gdjs.BossCode.mapOfGDgdjs_46BossCode_46GDStumpObjects1Objects, false, runtimeScene, false);
}if (gdjs.BossCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BossCode.GDSnowballObjects1 */
{for(var i = 0, len = gdjs.BossCode.GDSnowballObjects1.length ;i < len;++i) {
    gdjs.BossCode.GDSnowballObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
}

}


};

gdjs.BossCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BossCode.GDScoreObjects1.length = 0;
gdjs.BossCode.GDScoreObjects2.length = 0;
gdjs.BossCode.GDHealthObjects1.length = 0;
gdjs.BossCode.GDHealthObjects2.length = 0;
gdjs.BossCode.GDEnemyHealthObjects1.length = 0;
gdjs.BossCode.GDEnemyHealthObjects2.length = 0;
gdjs.BossCode.GDCongratsObjects1.length = 0;
gdjs.BossCode.GDCongratsObjects2.length = 0;
gdjs.BossCode.GDDieObjects1.length = 0;
gdjs.BossCode.GDDieObjects2.length = 0;
gdjs.BossCode.GDPlayerObjects1.length = 0;
gdjs.BossCode.GDPlayerObjects2.length = 0;
gdjs.BossCode.GDBulletObjects1.length = 0;
gdjs.BossCode.GDBulletObjects2.length = 0;
gdjs.BossCode.GDBossMonsterObjects1.length = 0;
gdjs.BossCode.GDBossMonsterObjects2.length = 0;
gdjs.BossCode.GDSnowballObjects1.length = 0;
gdjs.BossCode.GDSnowballObjects2.length = 0;
gdjs.BossCode.GDFallingSnowObjects1.length = 0;
gdjs.BossCode.GDFallingSnowObjects2.length = 0;
gdjs.BossCode.GDStumpObjects1.length = 0;
gdjs.BossCode.GDStumpObjects2.length = 0;
gdjs.BossCode.GDRunwayObjects1.length = 0;
gdjs.BossCode.GDRunwayObjects2.length = 0;
gdjs.BossCode.GDKeyObjects1.length = 0;
gdjs.BossCode.GDKeyObjects2.length = 0;
gdjs.BossCode.GDgateObjects1.length = 0;
gdjs.BossCode.GDgateObjects2.length = 0;
gdjs.BossCode.GDPlaneObjects1.length = 0;
gdjs.BossCode.GDPlaneObjects2.length = 0;
gdjs.BossCode.GDdarkObjects1.length = 0;
gdjs.BossCode.GDdarkObjects2.length = 0;
gdjs.BossCode.GDBarriorObjects1.length = 0;
gdjs.BossCode.GDBarriorObjects2.length = 0;
gdjs.BossCode.GDSignObjects1.length = 0;
gdjs.BossCode.GDSignObjects2.length = 0;

gdjs.BossCode.eventsList2(runtimeScene);
return;

}

gdjs['BossCode'] = gdjs.BossCode;
