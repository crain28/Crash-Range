gdjs.RangeCode = {};
gdjs.RangeCode.GDScoreObjects1= [];
gdjs.RangeCode.GDScoreObjects2= [];
gdjs.RangeCode.GDHealthObjects1= [];
gdjs.RangeCode.GDHealthObjects2= [];
gdjs.RangeCode.GDMessageObjects1= [];
gdjs.RangeCode.GDMessageObjects2= [];
gdjs.RangeCode.GDPlayerObjects1= [];
gdjs.RangeCode.GDPlayerObjects2= [];
gdjs.RangeCode.GDBulletObjects1= [];
gdjs.RangeCode.GDBulletObjects2= [];
gdjs.RangeCode.GDTargetObjects1= [];
gdjs.RangeCode.GDTargetObjects2= [];
gdjs.RangeCode.GDStandObjects1= [];
gdjs.RangeCode.GDStandObjects2= [];
gdjs.RangeCode.GDStumpObjects1= [];
gdjs.RangeCode.GDStumpObjects2= [];
gdjs.RangeCode.GDRunwayObjects1= [];
gdjs.RangeCode.GDRunwayObjects2= [];
gdjs.RangeCode.GDPlaneObjects1= [];
gdjs.RangeCode.GDPlaneObjects2= [];
gdjs.RangeCode.GDRunwayLightsObjects1= [];
gdjs.RangeCode.GDRunwayLightsObjects2= [];
gdjs.RangeCode.GDBarriorObjects1= [];
gdjs.RangeCode.GDBarriorObjects2= [];
gdjs.RangeCode.GDSignObjects1= [];
gdjs.RangeCode.GDSignObjects2= [];

gdjs.RangeCode.conditionTrue_0 = {val:false};
gdjs.RangeCode.condition0IsTrue_0 = {val:false};
gdjs.RangeCode.condition1IsTrue_0 = {val:false};
gdjs.RangeCode.condition2IsTrue_0 = {val:false};
gdjs.RangeCode.conditionTrue_1 = {val:false};
gdjs.RangeCode.condition0IsTrue_1 = {val:false};
gdjs.RangeCode.condition1IsTrue_1 = {val:false};
gdjs.RangeCode.condition2IsTrue_1 = {val:false};


gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.RangeCode.GDBulletObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDTargetObjects1Objects = Hashtable.newFrom({"Target": gdjs.RangeCode.GDTargetObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.RangeCode.GDBulletObjects1});gdjs.RangeCode.mapOf = Hashtable.newFrom({});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.RangeCode.GDPlayerObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.RangeCode.GDPlayerObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDSignObjects1Objects = Hashtable.newFrom({"Sign": gdjs.RangeCode.GDSignObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.RangeCode.GDBulletObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBarriorObjects1Objects = Hashtable.newFrom({"Barrior": gdjs.RangeCode.GDBarriorObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.RangeCode.GDPlayerObjects1});gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlaneObjects1Objects = Hashtable.newFrom({"Plane": gdjs.RangeCode.GDPlaneObjects1});gdjs.RangeCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.RangeCode.condition0IsTrue_0.val = false;
{
gdjs.RangeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.RangeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.preloadSound(runtimeScene, "Gun-Shot.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "126531__sinkhole7__tink3d.wav");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "grandpas-twist.mp3");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "grandpas-twist.mp3", false, 50, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.RangeCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.RangeCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("RunwayLights"), gdjs.RangeCode.GDRunwayLightsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Stump"), gdjs.RangeCode.GDStumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.RangeCode.GDTargetObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.RangeCode.GDPlayerObjects1.length !== 0 ? gdjs.RangeCode.GDPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.RangeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDPlayerObjects1[i].setScale(0.7);
}
}{for(var i = 0, len = gdjs.RangeCode.GDStumpObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDStumpObjects1[i].setScale(0.7);
}
}{for(var i = 0, len = gdjs.RangeCode.GDRunwayLightsObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDRunwayLightsObjects1[i].setScale(1.5);
}
}{for(var i = 0, len = gdjs.RangeCode.GDTargetObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDTargetObjects1[i].setScale(1.2);
}
}{for(var i = 0, len = gdjs.RangeCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDBulletObjects1[i].setScale(0.7);
}
}{}}

}


{


gdjs.RangeCode.condition0IsTrue_0.val = false;
gdjs.RangeCode.condition1IsTrue_0.val = false;
{
gdjs.RangeCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.RangeCode.condition0IsTrue_0.val ) {
{
{gdjs.RangeCode.conditionTrue_1 = gdjs.RangeCode.condition1IsTrue_0;
gdjs.RangeCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9961348);
}
}}
if (gdjs.RangeCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.RangeCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.RangeCode.GDPlayerObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "Gun-Shot.wav", false, 60, 1);
}{for(var i = 0, len = gdjs.RangeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDPlayerObjects1[i].getBehavior("FireBullet").Fire((gdjs.RangeCode.GDPlayerObjects1[i].getPointX("")), (gdjs.RangeCode.GDPlayerObjects1[i].getPointY("")), gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBulletObjects1Objects, (gdjs.RangeCode.GDPlayerObjects1[i].getBehavior("FaceForward").MovementDirection((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 600, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.RangeCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.RangeCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("Score")));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.RangeCode.GDHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.RangeCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.RangeCode.GDHealthObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDHealthObjects1[i].setString("Health: " + gdjs.evtTools.common.toString((( gdjs.RangeCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.RangeCode.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.RangeCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.RangeCode.GDTargetObjects1);

gdjs.RangeCode.condition0IsTrue_0.val = false;
{
gdjs.RangeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDTargetObjects1Objects, gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBulletObjects1Objects, false, runtimeScene, false);
}if (gdjs.RangeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.RangeCode.GDBulletObjects1 */
/* Reuse gdjs.RangeCode.GDTargetObjects1 */
{runtimeScene.getVariables().get("Score").add(100);
}{for(var i = 0, len = gdjs.RangeCode.GDTargetObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDTargetObjects1[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.RangeCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Tink.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.RangeCode.GDPlayerObjects1);

gdjs.RangeCode.condition0IsTrue_0.val = false;
{
gdjs.RangeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RangeCode.mapOf, gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.RangeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.RangeCode.GDPlayerObjects1 */
{}{for(var i = 0, len = gdjs.RangeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDPlayerObjects1[i].getBehavior("Health").Hit(20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.RangeCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sign"), gdjs.RangeCode.GDSignObjects1);

gdjs.RangeCode.condition0IsTrue_0.val = false;
{
gdjs.RangeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlayerObjects1Objects, gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDSignObjects1Objects, false, runtimeScene, false);
}if (gdjs.RangeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Message"), gdjs.RangeCode.GDMessageObjects1);
{for(var i = 0, len = gdjs.RangeCode.GDMessageObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDMessageObjects1[i].hide(false);
}
}}

}


{


{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barrior"), gdjs.RangeCode.GDBarriorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.RangeCode.GDBulletObjects1);

gdjs.RangeCode.condition0IsTrue_0.val = false;
{
gdjs.RangeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBulletObjects1Objects, gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDBarriorObjects1Objects, false, runtimeScene, false);
}if (gdjs.RangeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.RangeCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.RangeCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.RangeCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Plane"), gdjs.RangeCode.GDPlaneObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.RangeCode.GDPlayerObjects1);

gdjs.RangeCode.condition0IsTrue_0.val = false;
{
gdjs.RangeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlayerObjects1Objects, gdjs.RangeCode.mapOfGDgdjs_46RangeCode_46GDPlaneObjects1Objects, false, runtimeScene, false);
}if (gdjs.RangeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


{


{
}

}


};

gdjs.RangeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.RangeCode.GDScoreObjects1.length = 0;
gdjs.RangeCode.GDScoreObjects2.length = 0;
gdjs.RangeCode.GDHealthObjects1.length = 0;
gdjs.RangeCode.GDHealthObjects2.length = 0;
gdjs.RangeCode.GDMessageObjects1.length = 0;
gdjs.RangeCode.GDMessageObjects2.length = 0;
gdjs.RangeCode.GDPlayerObjects1.length = 0;
gdjs.RangeCode.GDPlayerObjects2.length = 0;
gdjs.RangeCode.GDBulletObjects1.length = 0;
gdjs.RangeCode.GDBulletObjects2.length = 0;
gdjs.RangeCode.GDTargetObjects1.length = 0;
gdjs.RangeCode.GDTargetObjects2.length = 0;
gdjs.RangeCode.GDStandObjects1.length = 0;
gdjs.RangeCode.GDStandObjects2.length = 0;
gdjs.RangeCode.GDStumpObjects1.length = 0;
gdjs.RangeCode.GDStumpObjects2.length = 0;
gdjs.RangeCode.GDRunwayObjects1.length = 0;
gdjs.RangeCode.GDRunwayObjects2.length = 0;
gdjs.RangeCode.GDPlaneObjects1.length = 0;
gdjs.RangeCode.GDPlaneObjects2.length = 0;
gdjs.RangeCode.GDRunwayLightsObjects1.length = 0;
gdjs.RangeCode.GDRunwayLightsObjects2.length = 0;
gdjs.RangeCode.GDBarriorObjects1.length = 0;
gdjs.RangeCode.GDBarriorObjects2.length = 0;
gdjs.RangeCode.GDSignObjects1.length = 0;
gdjs.RangeCode.GDSignObjects2.length = 0;

gdjs.RangeCode.eventsList0(runtimeScene);
return;

}

gdjs['RangeCode'] = gdjs.RangeCode;
