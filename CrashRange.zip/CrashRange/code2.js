gdjs.Level1Code = {};
gdjs.Level1Code.GDScoreObjects1= [];
gdjs.Level1Code.GDScoreObjects2= [];
gdjs.Level1Code.GDHealthObjects1= [];
gdjs.Level1Code.GDHealthObjects2= [];
gdjs.Level1Code.GDMessage1Objects1= [];
gdjs.Level1Code.GDMessage1Objects2= [];
gdjs.Level1Code.GDMessage2Objects1= [];
gdjs.Level1Code.GDMessage2Objects2= [];
gdjs.Level1Code.GDPlayerObjects1= [];
gdjs.Level1Code.GDPlayerObjects2= [];
gdjs.Level1Code.GDBulletObjects1= [];
gdjs.Level1Code.GDBulletObjects2= [];
gdjs.Level1Code.GDTargetObjects1= [];
gdjs.Level1Code.GDTargetObjects2= [];
gdjs.Level1Code.GDStandObjects1= [];
gdjs.Level1Code.GDStandObjects2= [];
gdjs.Level1Code.GDWolfObjects1= [];
gdjs.Level1Code.GDWolfObjects2= [];
gdjs.Level1Code.GDBearObjects1= [];
gdjs.Level1Code.GDBearObjects2= [];
gdjs.Level1Code.GDStumpObjects1= [];
gdjs.Level1Code.GDStumpObjects2= [];
gdjs.Level1Code.GDKeyObjects1= [];
gdjs.Level1Code.GDKeyObjects2= [];
gdjs.Level1Code.GDgateObjects1= [];
gdjs.Level1Code.GDgateObjects2= [];
gdjs.Level1Code.GDPlaneObjects1= [];
gdjs.Level1Code.GDPlaneObjects2= [];
gdjs.Level1Code.GDdarkObjects1= [];
gdjs.Level1Code.GDdarkObjects2= [];
gdjs.Level1Code.GDBarriorObjects1= [];
gdjs.Level1Code.GDBarriorObjects2= [];
gdjs.Level1Code.GDPlaneCrashObjects1= [];
gdjs.Level1Code.GDPlaneCrashObjects2= [];

gdjs.Level1Code.conditionTrue_0 = {val:false};
gdjs.Level1Code.condition0IsTrue_0 = {val:false};
gdjs.Level1Code.condition1IsTrue_0 = {val:false};
gdjs.Level1Code.condition2IsTrue_0 = {val:false};
gdjs.Level1Code.conditionTrue_1 = {val:false};
gdjs.Level1Code.condition0IsTrue_1 = {val:false};
gdjs.Level1Code.condition1IsTrue_1 = {val:false};
gdjs.Level1Code.condition2IsTrue_1 = {val:false};


gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level1Code.GDBulletObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDTargetObjects1Objects = Hashtable.newFrom({"Target": gdjs.Level1Code.GDTargetObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level1Code.GDBulletObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level1Code.GDBulletObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBearObjects1Objects = Hashtable.newFrom({"Bear": gdjs.Level1Code.GDBearObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level1Code.GDBulletObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDWolfObjects1Objects = Hashtable.newFrom({"Wolf": gdjs.Level1Code.GDWolfObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDWolfObjects1Objects = Hashtable.newFrom({"Wolf": gdjs.Level1Code.GDWolfObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBearObjects1Objects = Hashtable.newFrom({"Bear": gdjs.Level1Code.GDBearObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDKeyObjects1Objects = Hashtable.newFrom({"Key": gdjs.Level1Code.GDKeyObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDWolfObjects1ObjectsGDgdjs_46Level1Code_46GDBearObjects1Objects = Hashtable.newFrom({"Wolf": gdjs.Level1Code.GDWolfObjects1, "Bear": gdjs.Level1Code.GDBearObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDKeyObjects1Objects = Hashtable.newFrom({"Key": gdjs.Level1Code.GDKeyObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDgateObjects1Objects = Hashtable.newFrom({"gate": gdjs.Level1Code.GDgateObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDgateObjects1Objects = Hashtable.newFrom({"gate": gdjs.Level1Code.GDgateObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level1Code.GDBulletObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBarriorObjects1Objects = Hashtable.newFrom({"Barrior": gdjs.Level1Code.GDBarriorObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Level1Code.GDBulletObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDStumpObjects1Objects = Hashtable.newFrom({"Stump": gdjs.Level1Code.GDStumpObjects1});gdjs.Level1Code.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.preloadSound(runtimeScene, "Gun-Shot.wav");
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "grandpas-twist.mp3");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "grandpas-twist.mp3", false, 50, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.Level1Code.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level1Code.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Stump"), gdjs.Level1Code.GDStumpObjects1);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Level1Code.GDTargetObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wolf"), gdjs.Level1Code.GDWolfObjects1);
gdjs.copyArray(runtimeScene.getObjects("dark"), gdjs.Level1Code.GDdarkObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level1Code.GDPlayerObjects1.length !== 0 ? gdjs.Level1Code.GDPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].setScale(0.7);
}
}{for(var i = 0, len = gdjs.Level1Code.GDStumpObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDStumpObjects1[i].setScale(0.7);
}
}{for(var i = 0, len = gdjs.Level1Code.GDTargetObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTargetObjects1[i].setScale(1.2);
}
}{for(var i = 0, len = gdjs.Level1Code.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBulletObjects1[i].setScale(0.7);
}
}{for(var i = 0, len = gdjs.Level1Code.GDWolfObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDWolfObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointX("")), (( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointY("")));
}
for(var i = 0, len = gdjs.Level1Code.GDBearObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBearObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointX("")), (( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Level1Code.GDdarkObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDdarkObjects1[i].setOpacity(170);
}
}{for(var i = 0, len = gdjs.Level1Code.GDdarkObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDdarkObjects1[i].setPosition((( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointX("")),(( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointY("")));
}
}}

}


{


gdjs.Level1Code.condition0IsTrue_0.val = false;
gdjs.Level1Code.condition1IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.Level1Code.condition0IsTrue_0.val ) {
{
{gdjs.Level1Code.conditionTrue_1 = gdjs.Level1Code.condition1IsTrue_0;
gdjs.Level1Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10031180);
}
}}
if (gdjs.Level1Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level1Code.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "Gun-Shot.wav", false, 60, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("FireBullet").Fire((gdjs.Level1Code.GDPlayerObjects1[i].getPointX("")), (gdjs.Level1Code.GDPlayerObjects1[i].getPointY("")), gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects, (gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("FaceForward").MovementDirection((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 600, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level1Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Level1Code.GDHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDHealthObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHealthObjects1[i].setString("Health: " + gdjs.evtTools.common.toString((( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}}

}


{


{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level1Code.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Level1Code.GDTargetObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDTargetObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDBulletObjects1 */
/* Reuse gdjs.Level1Code.GDTargetObjects1 */
{runtimeScene.getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDTargetObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTargetObjects1[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.Level1Code.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.Level1Code.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level1Code.GDBulletObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBearObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDBearObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level1Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDBearObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBearObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(0).add(150);
}{for(var i = 0, len = gdjs.Level1Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDScoreObjects1[i].setString("150" + (gdjs.Level1Code.GDScoreObjects1[i].getString()));
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("Health").Heal(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level1Code.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wolf"), gdjs.Level1Code.GDWolfObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDWolfObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level1Code.GDScoreObjects1);
/* Reuse gdjs.Level1Code.GDWolfObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDWolfObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDWolfObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(0).add(100);
}{for(var i = 0, len = gdjs.Level1Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDScoreObjects1[i].setString("100" + (gdjs.Level1Code.GDScoreObjects1[i].getString()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level1Code.condition0IsTrue_0.val = true;
        gdjs.Level1Code.GDPlayerObjects1[k] = gdjs.Level1Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects1.length = k;}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "Spawn1");
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
gdjs.Level1Code.GDWolfObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDWolfObjects1Objects, gdjs.randomInRange(150, 350), -(10), "");
}{for(var i = 0, len = gdjs.Level1Code.GDWolfObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDWolfObjects1[i].setScale(gdjs.randomFloatInRange(1, 2));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn1");
}}

}


{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 7, "Spawn2");
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
gdjs.Level1Code.GDBearObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBearObjects1Objects, gdjs.randomInRange(800, 1000), -(10), "");
}{for(var i = 0, len = gdjs.Level1Code.GDBearObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBearObjects1[i].setScale(gdjs.randomFloatInRange(1, 2));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Spawn2");
}}

}


{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 2000;
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.Level1Code.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wolf"), gdjs.Level1Code.GDWolfObjects1);
gdjs.Level1Code.GDKeyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDKeyObjects1Objects, 500, 400, "");
}{for(var i = 0, len = gdjs.Level1Code.GDWolfObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDWolfObjects1[i].removeTimer("Spawn1");
}
}{for(var i = 0, len = gdjs.Level1Code.GDBearObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBearObjects1[i].removeTimer("Spawn2");
}
}{for(var i = 0, len = gdjs.Level1Code.GDWolfObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDWolfObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDBearObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBearObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.Level1Code.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wolf"), gdjs.Level1Code.GDWolfObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
gdjs.Level1Code.condition1IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDWolfObjects1ObjectsGDgdjs_46Level1Code_46GDBearObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Level1Code.condition0IsTrue_0.val ) {
{
{gdjs.Level1Code.conditionTrue_1 = gdjs.Level1Code.condition1IsTrue_0;
gdjs.Level1Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10044972);
}
}}
if (gdjs.Level1Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDPlayerObjects1 */
{}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("Health").Hit(20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Key"), gdjs.Level1Code.GDKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDPlayerObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDKeyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDKeyObjects1 */
gdjs.Level1Code.GDgateObjects1.length = 0;

{for(var i = 0, len = gdjs.Level1Code.GDKeyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDKeyObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mystery-harp.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDgateObjects1Objects, 800, -(140), "");
}{for(var i = 0, len = gdjs.Level1Code.GDgateObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDgateObjects1[i].setScale(2.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("gate"), gdjs.Level1Code.GDgateObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDPlayerObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDgateObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


{


{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Barrior"), gdjs.Level1Code.GDBarriorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level1Code.GDBulletObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBarriorObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDBulletObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Level1Code.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Stump"), gdjs.Level1Code.GDStumpObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDBulletObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDStumpObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDBulletObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
}

}


};

gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.GDScoreObjects1.length = 0;
gdjs.Level1Code.GDScoreObjects2.length = 0;
gdjs.Level1Code.GDHealthObjects1.length = 0;
gdjs.Level1Code.GDHealthObjects2.length = 0;
gdjs.Level1Code.GDMessage1Objects1.length = 0;
gdjs.Level1Code.GDMessage1Objects2.length = 0;
gdjs.Level1Code.GDMessage2Objects1.length = 0;
gdjs.Level1Code.GDMessage2Objects2.length = 0;
gdjs.Level1Code.GDPlayerObjects1.length = 0;
gdjs.Level1Code.GDPlayerObjects2.length = 0;
gdjs.Level1Code.GDBulletObjects1.length = 0;
gdjs.Level1Code.GDBulletObjects2.length = 0;
gdjs.Level1Code.GDTargetObjects1.length = 0;
gdjs.Level1Code.GDTargetObjects2.length = 0;
gdjs.Level1Code.GDStandObjects1.length = 0;
gdjs.Level1Code.GDStandObjects2.length = 0;
gdjs.Level1Code.GDWolfObjects1.length = 0;
gdjs.Level1Code.GDWolfObjects2.length = 0;
gdjs.Level1Code.GDBearObjects1.length = 0;
gdjs.Level1Code.GDBearObjects2.length = 0;
gdjs.Level1Code.GDStumpObjects1.length = 0;
gdjs.Level1Code.GDStumpObjects2.length = 0;
gdjs.Level1Code.GDKeyObjects1.length = 0;
gdjs.Level1Code.GDKeyObjects2.length = 0;
gdjs.Level1Code.GDgateObjects1.length = 0;
gdjs.Level1Code.GDgateObjects2.length = 0;
gdjs.Level1Code.GDPlaneObjects1.length = 0;
gdjs.Level1Code.GDPlaneObjects2.length = 0;
gdjs.Level1Code.GDdarkObjects1.length = 0;
gdjs.Level1Code.GDdarkObjects2.length = 0;
gdjs.Level1Code.GDBarriorObjects1.length = 0;
gdjs.Level1Code.GDBarriorObjects2.length = 0;
gdjs.Level1Code.GDPlaneCrashObjects1.length = 0;
gdjs.Level1Code.GDPlaneCrashObjects2.length = 0;

gdjs.Level1Code.eventsList0(runtimeScene);
return;

}

gdjs['Level1Code'] = gdjs.Level1Code;
