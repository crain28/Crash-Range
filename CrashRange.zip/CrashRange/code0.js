gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDTitleObjects1= [];
gdjs.MainMenuCode.GDTitleObjects2= [];
gdjs.MainMenuCode.GDTitleObjects3= [];
gdjs.MainMenuCode.GDCongratsObjects1= [];
gdjs.MainMenuCode.GDCongratsObjects2= [];
gdjs.MainMenuCode.GDCongratsObjects3= [];
gdjs.MainMenuCode.GDLevel1Objects1= [];
gdjs.MainMenuCode.GDLevel1Objects2= [];
gdjs.MainMenuCode.GDLevel1Objects3= [];
gdjs.MainMenuCode.GDRangeObjects1= [];
gdjs.MainMenuCode.GDRangeObjects2= [];
gdjs.MainMenuCode.GDRangeObjects3= [];
gdjs.MainMenuCode.GDBossObjects1= [];
gdjs.MainMenuCode.GDBossObjects2= [];
gdjs.MainMenuCode.GDBossObjects3= [];
gdjs.MainMenuCode.GDSnowpatchObjects1= [];
gdjs.MainMenuCode.GDSnowpatchObjects2= [];
gdjs.MainMenuCode.GDSnowpatchObjects3= [];

gdjs.MainMenuCode.conditionTrue_0 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_0 = {val:false};


gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRangeObjects1Objects = Hashtable.newFrom({"Range": gdjs.MainMenuCode.GDRangeObjects1});gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Range", false);
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Range", false);
}}

}


};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDLevel1Objects1Objects = Hashtable.newFrom({"Level1": gdjs.MainMenuCode.GDLevel1Objects1});gdjs.MainMenuCode.eventsList1 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDBossObjects1Objects = Hashtable.newFrom({"Boss": gdjs.MainMenuCode.GDBossObjects1});gdjs.MainMenuCode.eventsList2 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Boss", false);
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Boss", false);
}}

}


};gdjs.MainMenuCode.eventsList3 = function(runtimeScene) {

{



}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Congrats"), gdjs.MainMenuCode.GDCongratsObjects1);
{for(var i = 0, len = gdjs.MainMenuCode.GDCongratsObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDCongratsObjects1[i].hide();
}
}{gdjs.evtTools.sound.preloadMusic(runtimeScene, "grandpas-twist.mp3");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "grandpas-twist.mp3", true, 50, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Range"), gdjs.MainMenuCode.GDRangeObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRangeObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Level1"), gdjs.MainMenuCode.GDLevel1Objects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDLevel1Objects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Boss"), gdjs.MainMenuCode.GDBossObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDBossObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList2(runtimeScene);} //End of subevents
}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDTitleObjects1.length = 0;
gdjs.MainMenuCode.GDTitleObjects2.length = 0;
gdjs.MainMenuCode.GDTitleObjects3.length = 0;
gdjs.MainMenuCode.GDCongratsObjects1.length = 0;
gdjs.MainMenuCode.GDCongratsObjects2.length = 0;
gdjs.MainMenuCode.GDCongratsObjects3.length = 0;
gdjs.MainMenuCode.GDLevel1Objects1.length = 0;
gdjs.MainMenuCode.GDLevel1Objects2.length = 0;
gdjs.MainMenuCode.GDLevel1Objects3.length = 0;
gdjs.MainMenuCode.GDRangeObjects1.length = 0;
gdjs.MainMenuCode.GDRangeObjects2.length = 0;
gdjs.MainMenuCode.GDRangeObjects3.length = 0;
gdjs.MainMenuCode.GDBossObjects1.length = 0;
gdjs.MainMenuCode.GDBossObjects2.length = 0;
gdjs.MainMenuCode.GDBossObjects3.length = 0;
gdjs.MainMenuCode.GDSnowpatchObjects1.length = 0;
gdjs.MainMenuCode.GDSnowpatchObjects2.length = 0;
gdjs.MainMenuCode.GDSnowpatchObjects3.length = 0;

gdjs.MainMenuCode.eventsList3(runtimeScene);
return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
